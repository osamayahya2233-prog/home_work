enum ExtraAction { toggleAllComplete, clearCompleted }
