enum AppTab { todos, stats }
